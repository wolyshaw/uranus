//用于注册弹窗的对象
'use strict';
define({
	'samplePopup': {
		js: 'samplePopup',
		html: 'samplePopup.html',
		css: 'samplePopup.less',
		title: '示例弹窗'
	},
	'samplePopup2': {
		js: 'samplePopup2',
		html: 'samplePopup2.html',
		title: '示例弹窗2',
		back: 'samplePopup'
	},
	'page': {
		js: 'page',
		title: ''
	}
});
