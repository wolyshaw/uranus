(async() => {
	console.log(await import('./2.js'));
	console.log(await import('./2.js'));
})();