export function then (resolve, reject) {
	resolve('4.js');
}